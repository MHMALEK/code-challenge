export const toUpperCase = (string) => string.toUpperCase();

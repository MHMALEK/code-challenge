import { PrimaryTheme } from "./themes/primary/primary-theme";
import { defaultStyles } from "./defaults";
// this file used because it's help me to import all styles related files from one file(this file)
export { PrimaryTheme, defaultStyles };

export const defaultStyles = {
	fontSize: "14px",
	typography: {
		fontFamily: "Open Sans"
	},
	textColor: "white"
};

import styled from "styled-components/macro";

const SubTitle = styled.div`
	line-height: 1.67;
`;

export default SubTitle;

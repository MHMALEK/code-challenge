import styled from "styled-components";

const Header = styled.header`
	background-color: white;
	padding: 10px;
	text-align: center;
`;

export default Header;

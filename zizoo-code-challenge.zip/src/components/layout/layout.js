import Header from "./header";
import Footer from "./footer";

export { Header, Footer };

import styled from "styled-components";

const Footer = styled.footer`
	background-color: white;
	padding: 10px;
	text-align: center;
`;

export default Footer;

This project was developed by Mhos.malek for Zizoo Company for frontend developer role. there is some little description about the desicions I have made in project


## CRA over custom webpack config

I love to create my own customized projects with specefic webpack configs but in test and code challenges I thought it would take more time and that's not the purpose of test so I just used React create app (that's truely an amazing boilerplate)


## used StyledComponent for CSS
I always used  CSS Modules and really have good thought about it, but this time  I  used styled component. if to be honest, I didn't have any experinece so there might be some best practises that I didin't know about, but will learn about it soon.


I also used a custom created font-icon (I created this by Icomoon service). I don't think it was a good practise though and will change it if there was time!

at last happy Holidays for you and I Hope this is going well. 